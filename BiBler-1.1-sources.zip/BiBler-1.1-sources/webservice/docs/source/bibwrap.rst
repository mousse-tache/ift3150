Wrapper documentation
=====================

.. automodule:: bibwrap
   :members:

.. autoclass:: BiBlerWrapper
   :members: