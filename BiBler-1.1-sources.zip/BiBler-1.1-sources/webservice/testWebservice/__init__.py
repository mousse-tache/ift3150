'''
This package contains the modules to unit test the L{bibwrap.BiBlerWrapper} class.
'''
