'''
Created on Jan 13, 2014
@author: Eugene Syriani
@version: 0.7

This package contains the modules to unit test the L{app.UserInterface.UserInterface} class.
'''
