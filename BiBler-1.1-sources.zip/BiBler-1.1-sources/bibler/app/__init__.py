'''
.. moduleauthor:: Eugene Syriani

.. versionadded:: 1.0

Created on Nov 09, 2016

This package contains the modules that define the core behavior of the application.
'''