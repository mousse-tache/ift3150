'''
.. moduleauthor:: Eugene Syriani

.. versionadded:: 1.0

Created on Nov 09, 2016

This package contains the modules for rendering and controlling the graphical user interface.
'''