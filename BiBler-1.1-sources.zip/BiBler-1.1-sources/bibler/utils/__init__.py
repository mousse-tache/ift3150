'''
.. moduleauthor:: Eugene Syriani, Florin Oncica 

.. versionadded:: 0.9

Created on Nov 09, 2016

This package contains reusable utility modules, settings modules, and resource files.
'''